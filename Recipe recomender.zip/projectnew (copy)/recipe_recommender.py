import json
from typing import List, Dict
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

class RecipeRecommender:
    def __init__(self, recipes_file: str = 'recipes.json'):
        self.recipes = self._load_recipes(recipes_file)
        self.vectorizer = TfidfVectorizer(
            tokenizer=lambda x: x.split(','), 
            lowercase=True, 
            stop_words='english'
        )
        self._prepare_recipe_vectors()
    
    def _load_recipes(self, file_path: str) -> List[Dict]:
        try:
            with open(file_path, 'r') as f:
                return json.load(f)
        except FileNotFoundError:
            print(f"Warning: {file_path} not found. Starting with empty database.")
            return []
    
    def _prepare_recipe_vectors(self):
        if not self.recipes:
            return
        recipe_ingredients = [','.join(recipe['ingredients']) for recipe in self.recipes]
        self.ingredient_vectors = self.vectorizer.fit_transform(recipe_ingredients)
    
    def find_matching_recipes(self, available_ingredients: List[str], top_n: int = 5) -> List[Dict]:
        if not self.recipes:
            return []
        
        query = ','.join(available_ingredients)
        query_vector = self.vectorizer.transform([query])
        similarity_scores = cosine_similarity(query_vector, self.ingredient_vectors).flatten()
        top_indices = similarity_scores.argsort()[::-1][:top_n]
        
        return [{
            'recipe': self.recipes[i],
            'score': float(similarity_scores[i]),
            'missing_ingredients': self._get_missing_ingredients(
                self.recipes[i]['ingredients'], 
                available_ingredients
            )
        } for i in top_indices if similarity_scores[i] > 0]
    
    def _get_missing_ingredients(self, recipe_ingredients: List[str], available: List[str]) -> List[str]:
        available_set = set(i.lower() for i in available)
        return [ing for ing in recipe_ingredients if ing.lower() not in available_set]
    
    def add_recipe(
        self, 
        name: str, 
        ingredients: List[str], 
        instructions: str,
        meal_type: str = None,
        dietary_restrictions: List[str] = None,
        prep_time: int = None,
        cook_time: int = None,
        rating: float = None
    ):
        """Add a new recipe to the database with additional metadata.
        
        Args:
            name: Name of the recipe
            ingredients: List of ingredients
            instructions: Cooking instructions
            meal_type: Type of meal (e.g., 'breakfast', 'lunch', 'dinner', 'snack')
            dietary_restrictions: List of dietary restrictions (e.g., ['vegetarian', 'vegan'])
            prep_time: Preparation time in minutes
            cook_time: Cooking time in minutes
            rating: Recipe rating (0.0 to 5.0)
        """
        recipe = {
            'name': name,
            'ingredients': [i.strip().lower() for i in ingredients],
            'instructions': instructions,
            'meal_type': meal_type,
            'dietary_restrictions': dietary_restrictions or [],
            'prep_time': prep_time,
            'cook_time': cook_time,
            'rating': rating
        }
        self.recipes.append(recipe)
        self._prepare_recipe_vectors()
        return recipe
    
    def save_recipes(self, file_path: str = 'recipes.json') -> bool:
        """Save recipes to a JSON file.
        
        Args:
            file_path: Path to save the recipes file
            
        Returns:
            bool: True if save was successful, False otherwise
        """
        try:
            with open(file_path, 'w') as f:
                json.dump(self.recipes, f, indent=2)
            return True
        except Exception as e:
            print(f"Error saving recipes: {e}")
            return False
