import tkinter as tk
from tkinter import ttk, messagebox, scrolledtext
from typing import List, Dict
import json
import os
from recipe_recommender import RecipeRecommender

class RecipeApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Recipe Recommendation System")
        self.root.geometry("900x700")
        self.root.configure(bg='#f5f5f5')
        
        # Initialize the recommender
        self.recommender = RecipeRecommender()
        
        # Apply a modern theme
        self.style = ttk.Style()
        self.style.theme_use('clam')
        
        # Configure styles
        self.style.configure('TFrame', background='#f5f5f5')
        self.style.configure('TLabel', background='#f5f5f5', font=('Helvetica', 10))
        self.style.configure('TButton', font=('Helvetica', 10), padding=5)
        self.style.configure('TNotebook', background='#f5f5f5')
        self.style.configure('TNotebook.Tab', font=('Helvetica', 10, 'bold'), padding=[10, 5])
        
        # Create main container
        self.main_container = ttk.Frame(root, padding="10")
        self.main_container.pack(fill=tk.BOTH, expand=True)
        
        # Create notebook for tabs
        self.notebook = ttk.Notebook(self.main_container)
        self.notebook.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        # Create tabs
        self.create_find_recipes_tab()
        self.create_add_recipe_tab()
        self.create_view_recipes_tab()
        
        # Load sample recipes if none exist
        if not self.recommender.recipes:
            self.load_sample_recipes()
    
    def create_find_recipes_tab(self):
        """Create the 'Find Recipes' tab"""
        self.find_tab = ttk.Frame(self.notebook, padding="10")
        self.notebook.add(self.find_tab, text="Find Recipes")
        
        # Ingredients input
        ttk.Label(self.find_tab, text="Enter ingredients (comma-separated):", font=('Helvetica', 10, 'bold')).pack(anchor='w', pady=(0, 5))
        
        self.ingredients_entry = ttk.Entry(self.find_tab, width=80)
        self.ingredients_entry.pack(fill=tk.X, pady=(0, 10))
        self.ingredients_entry.insert(0, "paneer, tomato, garlic")  # Default example
        
        # Find button
        find_btn = ttk.Button(
            self.find_tab, 
            text="Find Recipes", 
            command=self.find_recipes,
            style='Accent.TButton'
        )
        find_btn.pack(pady=(0, 15))
        
        # Results frame
        results_frame = ttk.LabelFrame(self.find_tab, text="Matching Recipes", padding="10")
        results_frame.pack(fill=tk.BOTH, expand=True)
        
        # Create a treeview for results
        self.results_tree = ttk.Treeview(
            results_frame, 
            columns=('name', 'match', 'missing'), 
            show='headings',
            selectmode='browse'
        )
        
        # Configure treeview columns
        self.results_tree.heading('name', text='Recipe Name')
        self.results_tree.heading('match', text='Match %')
        self.results_tree.heading('missing', text='Missing Ingredients')
        
        self.results_tree.column('name', width=200)
        self.results_tree.column('match', width=80, anchor='center')
        self.results_tree.column('missing', width=350)
        
        # Add scrollbars
        y_scroll = ttk.Scrollbar(results_frame, orient=tk.VERTICAL, command=self.results_tree.yview)
        x_scroll = ttk.Scrollbar(results_frame, orient=tk.HORIZONTAL, command=self.results_tree.xview)
        self.results_tree.configure(yscrollcommand=y_scroll.set, xscrollcommand=x_scroll.set)
        
        # Grid layout
        self.results_tree.grid(row=0, column=0, sticky='nsew')
        y_scroll.grid(row=0, column=1, sticky='ns')
        x_scroll.grid(row=1, column=0, sticky='ew')
        
        # Configure grid weights
        results_frame.columnconfigure(0, weight=1)
        results_frame.rowconfigure(0, weight=1)
        
        # Bind double click to view recipe
        self.results_tree.bind('<Double-1>', self.show_recipe_details)
    
    def create_add_recipe_tab(self):
        """Create the 'Add Recipe' tab"""
        self.add_tab = ttk.Frame(self.notebook, padding="10")
        self.notebook.add(self.add_tab, text="Add Recipe")
        
        # Create a canvas and scrollbar for the form
        canvas = tk.Canvas(self.add_tab)
        scrollbar = ttk.Scrollbar(self.add_tab, orient="vertical", command=canvas.yview)
        scrollable_frame = ttk.Frame(canvas)
        
        scrollable_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )
        
        canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)
        
        # Pack the canvas and scrollbar
        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")
        
        # Form frame
        form_frame = ttk.Frame(scrollable_frame)
        form_frame.pack(fill=tk.X, pady=5, padx=5)
        
        # Recipe name
        ttk.Label(form_frame, text="Recipe Name:", font=('Helvetica', 10, 'bold')).grid(row=0, column=0, sticky='w', pady=5)
        self.recipe_name = ttk.Entry(form_frame, font=('Helvetica', 10))
        self.recipe_name.grid(row=0, column=1, columnspan=2, sticky='ew', padx=5, pady=5, ipady=3)
        
        # Meal Type
        ttk.Label(form_frame, text="Meal Type:", font=('Helvetica', 10, 'bold')).grid(row=1, column=0, sticky='w', pady=5)
        self.meal_type = ttk.Combobox(
            form_frame, 
            values=['breakfast', 'lunch', 'dinner', 'appetizer', 'snack', 'dessert', 'main course', 'side dish'],
            font=('Helvetica', 10),
            state='normal'
        )
        self.meal_type.grid(row=1, column=1, columnspan=2, sticky='ew', padx=5, pady=5, ipady=3)
        
        # Dietary Restrictions
        ttk.Label(form_frame, text="Dietary Restrictions:", font=('Helvetica', 10, 'bold')).grid(row=2, column=0, sticky='nw', pady=5)
        
        self.diet_vars = {
            'vegetarian': tk.BooleanVar(),
            'vegan': tk.BooleanVar(),
            'gluten-free': tk.BooleanVar(),
            'dairy-free': tk.BooleanVar(),
            'nut-free': tk.BooleanVar()
        }
        
        diet_frame = ttk.Frame(form_frame)
        diet_frame.grid(row=2, column=1, columnspan=2, sticky='w', padx=5, pady=5)
        
        for i, (diet, var) in enumerate(self.diet_vars.items()):
            cb = ttk.Checkbutton(
                diet_frame, 
                text=diet.title(), 
                variable=var,
                style='TCheckbutton'
            )
            cb.grid(row=i//2, column=i%2, sticky='w', padx=5, pady=2)
        
        # Prep Time
        ttk.Label(form_frame, text="Prep Time (minutes):", font=('Helvetica', 10, 'bold')).grid(row=3, column=0, sticky='w', pady=5)
        self.prep_time = ttk.Spinbox(
            form_frame, 
            from_=0, 
            to=1000, 
            width=5,
            font=('Helvetica', 10)
        )
        self.prep_time.grid(row=3, column=1, sticky='w', padx=5, pady=5, ipady=3)
        
        # Cook Time
        ttk.Label(form_frame, text="Cook Time (minutes):", font=('Helvetica', 10, 'bold')).grid(row=4, column=0, sticky='w', pady=5)
        self.cook_time = ttk.Spinbox(
            form_frame, 
            from_=0, 
            to=1000, 
            width=5,
            font=('Helvetica', 10)
        )
        self.cook_time.grid(row=4, column=1, sticky='w', padx=5, pady=5, ipady=3)
        
        # Rating
        ttk.Label(form_frame, text="Rating (1-5):", font=('Helvetica', 10, 'bold')).grid(row=5, column=0, sticky='w', pady=5)
        self.rating = ttk.Spinbox(
            form_frame, 
            from_=0, 
            to=5, 
            increment=0.1,
            width=5,
            font=('Helvetica', 10)
        )
        self.rating.grid(row=5, column=1, sticky='w', padx=5, pady=5, ipady=3)
        
        # Ingredients
        ttk.Label(form_frame, text="Ingredients (one per line):", font=('Helvetica', 10, 'bold')).grid(row=6, column=0, sticky='nw', pady=5)
        self.ingredients_text = scrolledtext.ScrolledText(
            form_frame, 
            width=50, 
            height=5,
            font=('Helvetica', 10),
            wrap=tk.WORD
        )
        self.ingredients_text.grid(row=6, column=1, columnspan=2, sticky='ew', padx=5, pady=5)
        
        # Instructions
        ttk.Label(form_frame, text="Instructions:", font=('Helvetica', 10, 'bold')).grid(row=7, column=0, sticky='nw', pady=5)
        self.instructions_text = scrolledtext.ScrolledText(
            form_frame, 
            width=50, 
            height=10,
            font=('Helvetica', 10),
            wrap=tk.WORD
        )
        self.instructions_text.grid(row=7, column=1, columnspan=2, sticky='nsew', padx=5, pady=5)
        
        # Button frame
        button_frame = ttk.Frame(form_frame)
        button_frame.grid(row=8, column=0, columnspan=3, pady=15)
        
        # Add button
        add_btn = ttk.Button(
            button_frame, 
            text="Add Recipe", 
            command=self.add_recipe,
            style='Accent.TButton',
            padding=10
        )
        add_btn.pack(side=tk.RIGHT, padx=5)
        
        # Clear button
        clear_btn = ttk.Button(
            button_frame,
            text="Clear Form",
            command=self.clear_recipe_form,
            padding=10
        )
        clear_btn.pack(side=tk.RIGHT, padx=5)
        
        # Configure grid weights
        form_frame.columnconfigure(1, weight=1)
        form_frame.rowconfigure(7, weight=1)
        
        # Configure the canvas to update scroll region when window is resized
        def on_configure(event):
            canvas.configure(scrollregion=canvas.bbox("all"))
            
        form_frame.bind("<Configure>", on_configure)
        
        # Enable mouse wheel scrolling
        def _on_mousewheel(event):
            canvas.yview_scroll(int(-1*(event.delta/120)), "units")
            
        canvas.bind_all("<MouseWheel>", _on_mousewheel)
    
    def create_view_recipes_tab(self):
        """Create the 'View Recipes' tab"""
        self.view_tab = ttk.Frame(self.notebook, padding="10")
        self.notebook.add(self.view_tab, text="View Recipes")
        
        # Create a treeview for all recipes
        self.recipes_tree = ttk.Treeview(
            self.view_tab, 
            columns=('name', 'meal_type', 'ingredients_count', 'total_time', 'rating'), 
            show='headings',
            selectmode='browse'
        )
        
        # Configure treeview columns
        self.recipes_tree.heading('name', text='Recipe Name')
        self.recipes_tree.heading('meal_type', text='Meal Type')
        self.recipes_tree.heading('ingredients_count', text='Ingredients')
        self.recipes_tree.heading('total_time', text='Total Time')
        self.recipes_tree.heading('rating', text='Rating')
        
        # Set column widths and alignment
        self.recipes_tree.column('name', width=250, anchor='w')
        self.recipes_tree.column('meal_type', width=100, anchor='center')
        self.recipes_tree.column('ingredients_count', width=80, anchor='center')
        self.recipes_tree.column('total_time', width=80, anchor='center')
        self.recipes_tree.column('rating', width=80, anchor='center')
        
        # Add scrollbars
        y_scroll = ttk.Scrollbar(self.view_tab, orient=tk.VERTICAL, command=self.recipes_tree.yview)
        x_scroll = ttk.Scrollbar(self.view_tab, orient=tk.HORIZONTAL, command=self.recipes_tree.xview)
        self.recipes_tree.configure(yscrollcommand=y_scroll.set, xscrollcommand=x_scroll.set)
        
        # Grid layout
        self.recipes_tree.grid(row=0, column=0, sticky='nsew')
        y_scroll.grid(row=0, column=1, sticky='ns')
        x_scroll.grid(row=1, column=0, sticky='ew')
        
        # Configure grid weights
        self.view_tab.columnconfigure(0, weight=1)
        self.view_tab.rowconfigure(0, weight=1)
        
        # Bind double click to view recipe
        self.recipes_tree.bind('<Double-1>', self.view_recipe_from_list)
        
        # Populate the tree
        self.update_recipes_list()
    
    def find_recipes(self):
        """Find recipes based on ingredients"""
        ingredients = self.ingredients_entry.get().strip()
        if not ingredients:
            messagebox.showwarning("Input Error", "Please enter at least one ingredient.")
            return
        
        # Clear previous results
        for item in self.results_tree.get_children():
            self.results_tree.delete(item)
        
        # Get matching recipes
        ingredients_list = [i.strip() for i in ingredients.split(',') if i.strip()]
        matches = self.recommender.find_matching_recipes(ingredients_list)
        
        if not matches:
            messagebox.showinfo("No Matches", "No recipes found with the given ingredients.")
            return
        
        # Add matches to the treeview
        for match in matches:
            recipe = match['recipe']
            self.results_tree.insert('', 'end', 
                values=(
                    recipe['name'],
                    f"{match['score']*100:.1f}%",
                    ', '.join(match['missing_ingredients']) or 'None'
                ),
                tags=('recipe',)
            )
    
    def show_recipe_details(self, event):
        """Show details of the selected recipe"""
        selected_item = self.results_tree.selection()
        if not selected_item:
            return
            
        # Get the recipe name from the treeview
        recipe_name = self.results_tree.item(selected_item, 'values')[0]
        
        # Find the recipe in the database
        for recipe in self.recommender.recipes:
            if recipe['name'] == recipe_name:
                self.display_recipe_details(recipe)
                break
    
    def view_recipe_from_list(self, event):
        """View recipe details from the 'View Recipes' tab"""
        selected_item = self.recipes_tree.selection()
        if not selected_item:
            return
            
        # Get the recipe name from the treeview
        recipe_name = self.recipes_tree.item(selected_item, 'values')[0]
        
        # Find the recipe in the database
        for recipe in self.recommender.recipes:
            if recipe['name'] == recipe_name:
                self.display_recipe_details(recipe)
                break
    
    def display_recipe_details(self, recipe):
        """Display recipe details in a new window"""
        # Create a new top-level window
        details_win = tk.Toplevel(self.root)
        details_win.title(recipe['name'])
        details_win.geometry("700x700")
        
        # Create main container with scrollbar
        main_frame = ttk.Frame(details_win)
        main_frame.pack(fill=tk.BOTH, expand=True)
        
        # Add a canvas and scrollbar
        canvas = tk.Canvas(main_frame)
        scrollbar = ttk.Scrollbar(main_frame, orient="vertical", command=canvas.yview)
        scrollable_frame = ttk.Frame(canvas)
        
        scrollable_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )
        
        canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)
        
        # Pack the canvas and scrollbar
        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")
        
        # Create container for recipe details
        container = ttk.Frame(scrollable_frame, padding="15")
        container.pack(fill=tk.BOTH, expand=True)
        
        # Recipe name and rating
        header_frame = ttk.Frame(container)
        header_frame.pack(fill=tk.X, pady=(0, 15))
        
        ttk.Label(
            header_frame, 
            text=recipe['name'], 
            font=('Helvetica', 16, 'bold')
        ).pack(side=tk.LEFT)
        
        if 'rating' in recipe and recipe['rating'] is not None:
            rating_frame = ttk.Frame(header_frame)
            rating_frame.pack(side=tk.RIGHT, padx=10)
            
            # Display star rating
            stars = '★' * int(recipe['rating']) + '☆' * (5 - int(recipe['rating']))
            ttk.Label(
                rating_frame,
                text=f"{stars} {recipe['rating']}",
                foreground='gold',
                font=('Helvetica', 12, 'bold')
            ).pack()
        
        # Recipe metadata
        meta_frame = ttk.Frame(container)
        meta_frame.pack(fill=tk.X, pady=(0, 15))
        
        # Meal type
        if 'meal_type' in recipe and recipe['meal_type']:
            ttk.Label(
                meta_frame,
                text=f"Meal: {recipe['meal_type'].title()}",
                font=('Helvetica', 10, 'bold')
            ).pack(anchor='w')
        
        # Dietary restrictions
        if 'dietary_restrictions' in recipe and recipe['dietary_restrictions']:
            restrictions = ", ".join(r.title() for r in recipe['dietary_restrictions'])
            ttk.Label(
                meta_frame,
                text=f"Dietary: {restrictions}",
                font=('Helvetica', 10)
            ).pack(anchor='w')
        
        # Prep and cook time
        time_info = []
        if 'prep_time' in recipe and recipe['prep_time'] is not None:
            time_info.append(f"Prep: {recipe['prep_time']} min")
        if 'cook_time' in recipe and recipe['cook_time'] is not None:
            time_info.append(f"Cook: {recipe['cook_time']} min")
        
        if time_info:
            ttk.Label(
                meta_frame,
                text=" | ".join(time_info),
                font=('Helvetica', 10)
            ).pack(anchor='w', pady=(5, 0))
        
        # Ingredients section
        ttk.Label(
            container, 
            text="Ingredients:", 
            font=('Helvetica', 12, 'bold')
        ).pack(anchor='w', pady=(10, 5))
        
        ingredients_frame = ttk.Frame(container)
        ingredients_frame.pack(fill=tk.X, pady=(0, 15))
        
        for i, ingredient in enumerate(recipe['ingredients'], 1):
            ttk.Label(
                ingredients_frame, 
                text=f"• {ingredient}",
                font=('Helvetica', 10)
            ).pack(anchor='w', padx=10)
        
        # Instructions section
        ttk.Label(
            container, 
            text="Instructions:", 
            font=('Helvetica', 12, 'bold')
        ).pack(anchor='w', pady=(10, 5))
        
        instructions_text = scrolledtext.ScrolledText(
            container,
            wrap=tk.WORD,
            width=70,
            height=15,
            font=('Helvetica', 10),
            padx=5,
            pady=5
        )
        instructions_text.insert('1.0', recipe['instructions'])
        instructions_text.config(state='disabled')
        instructions_text.pack(fill=tk.BOTH, expand=True, pady=(5, 0))
        
        # Configure the canvas to update scroll region when window is resized
        def on_configure(event):
            canvas.configure(scrollregion=canvas.bbox("all"))
            
        container.bind("<Configure>", on_configure)
        
        # Enable mouse wheel scrolling
        def _on_mousewheel(event):
            canvas.yview_scroll(int(-1*(event.delta/120)), "units")
            
        canvas.bind_all("<MouseWheel>", _on_mousewheel)
    
    def add_recipe(self):
        """Add a new recipe to the database"""
        name = self.recipe_name.get().strip()
        ingredients = self.ingredients_text.get('1.0', tk.END).strip().split('\n')
        instructions = self.instructions_text.get('1.0', tk.END).strip()
        
        # Validate input
        if not name:
            messagebox.showwarning("Input Error", "Please enter a recipe name.")
            return
        
        ingredients = [i.strip() for i in ingredients if i.strip()]
        if not ingredients:
            messagebox.showwarning("Input Error", "Please enter at least one ingredient.")
            return
        
        if not instructions:
            messagebox.showwarning("Input Error", "Please enter recipe instructions.")
            return
        
        # Get selected dietary restrictions
        dietary_restrictions = [d for d, var in self.diet_vars.items() if var.get()]
        
        # Get prep and cook times, handling empty values
        try:
            prep_time = int(self.prep_time.get()) if self.prep_time.get().strip() else None
            cook_time = int(self.cook_time.get()) if self.cook_time.get().strip() else None
            rating = float(self.rating.get()) if self.rating.get().strip() else None
        except ValueError:
            messagebox.showerror("Input Error", "Please enter valid numbers for prep time, cook time, and rating.")
            return
        
        # Validate rating
        if rating is not None and (rating < 0 or rating > 5):
            messagebox.showerror("Input Error", "Rating must be between 0 and 5.")
            return
        
        # Add the recipe
        try:
            self.recommender.add_recipe(
                name=name,
                ingredients=ingredients,
                instructions=instructions,
                meal_type=self.meal_type.get().strip() or None,
                dietary_restrictions=dietary_restrictions,
                prep_time=prep_time,
                cook_time=cook_time,
                rating=rating
            )
            self.recommender.save_recipes()
            
            # Clear the form
            self.clear_recipe_form()
            
            # Update the recipes list
            self.update_recipes_list()
            
            # Switch to the View Recipes tab
            self.notebook.select(2)  # Assuming View Recipes is the third tab (0-indexed)
            
            messagebox.showinfo("Success", f"Recipe '{name}' has been added successfully!")
            
        except Exception as e:
            messagebox.showerror("Error", f"An error occurred while adding the recipe: {str(e)}")
    
    def clear_recipe_form(self):
        """Clear all fields in the add recipe form"""
        self.recipe_name.delete(0, tk.END)
        self.meal_type.set('')
        
        # Clear all dietary restriction checkboxes
        for var in self.diet_vars.values():
            var.set(False)
        
        # Clear numeric fields
        self.prep_time.delete(0, tk.END)
        self.prep_time.insert(0, '0')
        
        self.cook_time.delete(0, tk.END)
        self.cook_time.insert(0, '0')
        
        self.rating.delete(0, tk.END)
        self.rating.insert(0, '0.0')
        
        # Clear text areas
        self.ingredients_text.delete('1.0', tk.END)
        self.instructions_text.delete('1.0', tk.END)
        
        # Set focus back to recipe name
        self.recipe_name.focus_set()
    
    def update_recipes_list(self):
        """Update the recipes list in the View Recipes tab"""
        # Clear existing items
        for item in self.recipes_tree.get_children():
            self.recipes_tree.delete(item)
        
        # Add all recipes to the treeview
        for recipe in self.recommender.recipes:
            self.recipes_tree.insert('', 'end', 
                values=(
                    recipe['name'],
                    recipe.get('meal_type', 'N/A'),
                    len(recipe['ingredients']),
                    f"{recipe.get('prep_time', 0) + recipe.get('cook_time', 0)} min",
                    f"{recipe.get('rating', 'N/A')}"
                ),
                tags=('recipe',)
            )
    
    def load_sample_recipes(self):
        """Load sample recipes if the database is empty"""
        sample_recipes = [
            {
                'name': 'Dahi Puri',
                'ingredients': ['puri', 'yogurt', 'chickpeas', 'potatoes', 'tamarind chutney', 'spices'],
                'meal_type': 'snack',
                'dietary_restrictions': ['vegetarian'],
                'prep_time': 15,
                'cook_time': 0,
                'instructions': '1. Fill puris with a mixture of chickpeas and mashed potatoes.\n2. Top with yogurt, tamarind chutney, and spices.\n3. Serve immediately for a crunchy snack.',
                'rating': 4.6
            },
            {
                'name': 'Masala Dosa',
                'ingredients': ['rice batter', 'urad dal', 'potatoes', 'onions', 'spices', 'oil'],
                'meal_type': 'breakfast',
                'dietary_restrictions': ['vegetarian', 'vegan'],
                'prep_time': 30,
                'cook_time': 20,
                'instructions': '1. Prepare dosa batter and let it ferment.\n2. Spread batter on a hot griddle to make thin crepes.\n3. Fill with spiced potato and onion mixture.\n4. Serve with sambar and chutney.',
                'rating': 4.8
            },
            {
                'name': 'Paneer Tikka',
                'ingredients': ['paneer', 'bell peppers', 'onions', 'yogurt', 'spices'],
                'meal_type': 'appetizer',
                'dietary_restrictions': ['vegetarian'],
                'prep_time': 20,
                'cook_time': 15,
                'instructions': '1. Marinate paneer and vegetables in spiced yogurt.\n2. Skewer and grill until slightly charred.\n3. Serve hot with mint chutney.',
                'rating': 4.7
            },
            {
                'name': 'Chicken Biryani',
                'ingredients': ['basmati rice', 'chicken', 'yogurt', 'onions', 'tomatoes', 'spices'],
                'meal_type': 'main course',
                'dietary_restrictions': [],
                'prep_time': 30,
                'cook_time': 40,
                'instructions': '1. Marinate chicken with yogurt and spices.\n2. Partially cook rice with whole spices.\n3. Layer rice and chicken, then cook on dum.\n4. Serve with raita and salad.',
                'rating': 4.9
            },
            {
                'name': 'Gulab Jamun',
                'ingredients': ['khoya', 'milk powder', 'sugar', 'cardamom', 'ghee'],
                'meal_type': 'dessert',
                'dietary_restrictions': ['vegetarian'],
                'prep_time': 20,
                'cook_time': 20,
                'instructions': '1. Make dough with khoya and milk powder.\n2. Shape into balls and deep fry.\n3. Soak in sugar syrup flavored with cardamom.\n4. Serve warm or chilled.',
                'rating': 4.8
            }
        ]
        
        for recipe in sample_recipes:
            self.recommender.add_recipe(
                recipe['name'],
                recipe['ingredients'],
                recipe['instructions'],
                meal_type=recipe.get('meal_type'),
                dietary_restrictions=recipe.get('dietary_restrictions', []),
                prep_time=recipe.get('prep_time'),
                cook_time=recipe.get('cook_time'),
                rating=recipe.get('rating')
            )
        
        self.recommender.save_recipes()
        self.update_recipes_list()

def main():
    root = tk.Tk()
    app = RecipeApp(root)
    root.mainloop()

if __name__ == "__main__":
    main()
