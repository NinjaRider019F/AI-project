# Recipe Recommendation System

A modern GUI application that suggests recipes based on the ingredients you have available. The system finds the most relevant recipes for your available ingredients.

## Features

- 🖥️ Intuitive graphical user interface
- 🔍 Search recipes by available ingredients
- 📝 View detailed recipe information including:
  - Ingredients list
  - Step-by-step instructions
  - Preparation and cooking times
  - Meal type and dietary restrictions
  - Recipe ratings
- ➕ Add new recipes with custom details
- 📋 Browse all available recipes
- 🔄 Real-time search and filtering
- 📊 Smart ingredient matching with similarity scoring

## Installation

1. Clone the repository:
   ```bash
   git clone <repository-url>
   cd recipe-recommender
   ```

2. Create and activate a virtual environment (recommended):
   ```bash
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   ```

3. Install the required packages:
   ```bash
   pip install -r requirements.txt
   ```

## Usage

Run the application:
```bash
python gui_app.py
```

### Application Tabs

1. **Find Recipes**
   - Enter ingredients you have available (comma-separated)
   - View matching recipes sorted by relevance
   - Double-click any recipe to view full details

2. **Add Recipe**
   - Add your own recipes to the database
   - Enter recipe details including:
     - Name and description
     - Ingredients (one per line)
     - Step-by-step instructions
     - Meal type and dietary restrictions
     - Preparation and cooking times
     - Rating (optional)

3. **View Recipes**
   - Browse all recipes in the database
   - Double-click any recipe to view full details
   - See at-a-glance information about each recipe

## Data Storage

Recipes are stored in a `recipes.json` file in the project directory. The file is automatically managed by the application.

## Requirements

- Python 3.8+
- scikit-learn
- numpy
- tkinter (usually included with Python)
